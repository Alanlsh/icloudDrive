//
//  ViewController.m
//  iclouddrive
//
//  Created by Alan on 2019/7/23.
//  Copyright © 2019 Alan. All rights reserved.
//

#import "ViewController.h"
#import "DocumentManager.h"
@interface ViewController ()<UIDocumentInteractionControllerDelegate,UIDocumentPickerDelegate>


//@property (nonatomic,strong) UIDocumentInteractionController * document;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    NSString *cachePath = [[NSBundle mainBundle] pathForResource:@"Wewewefafea" ofType:@"docx"];
//    NSURL * pathUrl = [NSURL fileURLWithPath:cachePath];//文件路径
    //1.指定要分享的链
   //  _document = [UIDocumentInteractionController interactionControllerWithURL:pathUrl];
    //2.设置分享代理
      //  _document.delegate =  (id)self;
    //3.哪类文件支持第三方打开，这里不证明就代表所有文件！
    //    _document.UTI = @"com.microsoft.word.doc";
    //4.判断手机中有没有应用可以打开该文件并打开分享界面
    // 用户预览文件，如图1所示
    //BOOL canOpen =   [_document presentPreviewAnimated:YES];
    // 用户不预览文件直接分享，如图2所示
//
//    BOOL canOpen = [self.document presentOpenInMenuFromRect:self.view.bounds inView:self.view animated:YES];
//
//        if(!canOpen) {
//           NSLog(@"沒有程序可以打开选中的文件");
//    }else{
//        [self.document presentPreviewAnimated:YES];//跳转到查看页面
//    }
    
//    NSString *cachePath = [[NSBundle mainBundle] pathForResource:@"Wewewefafea" ofType:@"docx"];
//    NSURL * pathUrl = [NSURL fileURLWithPath:cachePath];//文件路径
//    UIDocumentInteractionController *documentController = [UIDocumentInteractionController interactionControllerWithURL:pathUrl];
//    documentController.delegate = self;
//    [documentController presentPreviewAnimated:YES];//跳转到查看页面
  
    
//    BOOL canOpen = [documentController presentOpenInMenuFromRect:self.view.bounds inView:self.view animated:YES];
//
//    if(!canOpen) {
//           NSLog(@"沒有程序可以打开选中的文件");
//    }else{
//        //[documentController presentPreviewAnimated:YES];//跳转到查看页面
//    }
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 20, 100, 100)];
    button.backgroundColor = [UIColor redColor];
    [button setTitle:@"打开" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonClicekd) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIButton *addbutton = [[UIButton alloc] initWithFrame:CGRectMake(0, 200, 100, 100)];
    addbutton.backgroundColor = [UIColor yellowColor];
    [addbutton setTitle:@"添加" forState:UIControlStateNormal];
    [addbutton addTarget:self action:@selector(pickFile) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:addbutton];
}
    
- (void)buttonClicekd
{
    DocumentManager *documentManager = [DocumentManager shareManager];
    //docx
    NSString *cachePath = [[NSBundle mainBundle] pathForResource:@"Wewewefafea" ofType:@"docx"];
    //png
    NSString *picPath = [[NSBundle mainBundle] pathForResource:@"4963135-7ae3f18749eff879" ofType:@"png"];
    //mp4
    NSString *md4Path = [[NSBundle mainBundle] pathForResource:@"1563865698050776" ofType:@"mp4"];
    
    [documentManager openfile:md4Path];
}

- (void)pickFile
{
    DocumentManager *documentManager = [DocumentManager shareManager];
    [documentManager pickfile:^(NSString * _Nonnull urlString) {
        NSLog(@"====================%@",urlString);
    }];
    
    
//    NSArray *documentTypes = @[@"public.content", @"public.text", @"public.source-code ", @"public.image", @"public.audiovisual-content", @"com.adobe.pdf", @"com.apple.keynote.key", @"com.microsoft.word.doc", @"com.microsoft.excel.xls", @"com.microsoft.powerpoint.ppt"];
//
//    UIDocumentPickerViewController *documentPicker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:documentTypes inMode:UIDocumentPickerModeOpen];
//    documentPicker.delegate = self;
//    documentPicker.modalPresentationStyle = UIModalPresentationFormSheet;
//    [self presentViewController:documentPicker animated:YES completion:nil];
}


#pragma mark - UIDocumentInteractionControllerDelegate
- (UIViewController*)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController*)controller{
        return self;
}
- (UIView*)documentInteractionControllerViewForPreview:(UIDocumentInteractionController*)controller {
        return self.view;
}
- (CGRect)documentInteractionControllerRectForPreview:(UIDocumentInteractionController*)controller {
        return self.view.frame;
}
//点击预览窗口的“Done”(完成)按钮时调用
- (void)documentInteractionControllerDidEndPreview:(UIDocumentInteractionController*)controller {
}
// 文件分享面板弹出的时候调用
- (void)documentInteractionControllerWillPresentOpenInMenu:(UIDocumentInteractionController*)controller{
        NSLog(@"WillPresentOpenInMenu");
}
// 当选择一个文件分享App的时候调用
- (void)documentInteractionController:(UIDocumentInteractionController*)controller willBeginSendingToApplication:(nullable NSString*)application{
        NSLog(@"begin send : %@", application);
}
// 弹框消失的时候走的方法
-(void)documentInteractionControllerDidDismissOpenInMenu:(UIDocumentInteractionController*)controller{
        NSLog(@"dissMiss");
}

#pragma mark - UIDocumentPickerDelegate
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray <NSURL *>*)urls NS_AVAILABLE_IOS(11_0)
{
    NSURL *url = urls[0];
    NSString *fileName = [url lastPathComponent];
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSLog(@"");
}

// called if the user dismisses the document picker without selecting a document (using the Cancel button)
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller
{
    
}

// 选中icloud里的pdf文件
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {
    BOOL fileUrlAuthozied = [url startAccessingSecurityScopedResource];
    if(fileUrlAuthozied){
        NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] init];
        NSError *error;
        
        [fileCoordinator coordinateReadingItemAtURL:url options:0 error:&error byAccessor:^(NSURL *newURL) {
            
            [self dismissViewControllerAnimated:YES completion:NULL];
            //[self sendFileMessageWithURL:newURL displayName:[[url path] lastPathComponent]];
        }];
        [url stopAccessingSecurityScopedResource];
    }else{
        //Error handling
        
    }
}


@end
