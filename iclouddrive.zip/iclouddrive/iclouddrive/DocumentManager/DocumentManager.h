//
//  DocumentManager.h
//  iclouddrive
//
//  Created by Alan on 2019/7/23.
//  Copyright © 2019 Alan. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DocumentManager : NSObject

+ (instancetype)shareManager;

/// 打开浏览文件
- (void)openfile:(NSString *)urlSting;

/// 从iCloud 获取并保存本地 返回文件夹路径
- (void)pickfile:(void(^)(NSString *urlString))pickfileBlock;


@end

NS_ASSUME_NONNULL_END
