//
//  DocumentManager.m
//  iclouddrive
//
//  Created by Alan on 2019/7/23.
//  Copyright © 2019 Alan. All rights reserved.
//

#import "DocumentManager.h"
#import "iCloudManager.h"
@interface DocumentManager ()<UIDocumentInteractionControllerDelegate,UIDocumentPickerDelegate>

@property (nonatomic, copy) void(^pickfileBlock)(NSString *urlStrirng);

@end

@implementation DocumentManager
static DocumentManager *_Manager = nil;
+ (instancetype)shareManager
{
    if (!_Manager) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _Manager = [[DocumentManager alloc] init];
        });
    }
    return _Manager;
}

- (void)openfile:(NSString *)urlSting
{
    if (urlSting && urlSting.length > 0) {
        NSURL *filePath = [NSURL fileURLWithPath:urlSting];
        UIDocumentInteractionController *documentController = [UIDocumentInteractionController interactionControllerWithURL:filePath];
        documentController.delegate = self;
        [documentController presentPreviewAnimated:YES];//跳转到查看页面
    }
}

- (void)pickfile:(void(^)(NSString *urlString))pickfileBlock
{
    self.pickfileBlock = pickfileBlock;
    NSArray *documentTypes = @[@"public.content", @"public.text", @"public.source-code ", @"public.image", @"public.audiovisual-content", @"com.adobe.pdf", @"com.apple.keynote.key", @"com.microsoft.word.doc", @"com.microsoft.excel.xls", @"com.microsoft.powerpoint.ppt"];
    
    UIDocumentPickerViewController *documentPicker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:documentTypes inMode:UIDocumentPickerModeOpen];
    documentPicker.delegate = self;
    documentPicker.modalPresentationStyle = UIModalPresentationFormSheet;
    UIViewController *rootVC = [UIApplication sharedApplication].delegate.window.rootViewController;
    [rootVC presentViewController:documentPicker animated:YES completion:nil];
    //[self presentViewController:documentPicker animated:YES completion:nil];
}


#pragma mark - UIDocumentInteractionControllerDelegate
- (UIViewController*)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController*)controller
{
    UIViewController *rootVC = [UIApplication sharedApplication].delegate.window.rootViewController;
    return rootVC;
}
- (UIView*)documentInteractionControllerViewForPreview:(UIDocumentInteractionController*)controller {
    UIViewController *rootVC = [UIApplication sharedApplication].delegate.window.rootViewController;
    return rootVC.view;
}
- (CGRect)documentInteractionControllerRectForPreview:(UIDocumentInteractionController*)controller {
    UIViewController *rootVC = [UIApplication sharedApplication].delegate.window.rootViewController;
    return rootVC.view.frame;
}
//点击预览窗口的“Done”(完成)按钮时调用
- (void)documentInteractionControllerDidEndPreview:(UIDocumentInteractionController*)controller
{
}
// 文件分享面板弹出的时候调用
- (void)documentInteractionControllerWillPresentOpenInMenu:(UIDocumentInteractionController*)controller
{
    NSLog(@"WillPresentOpenInMenu");
}
// 当选择一个文件分享App的时候调用
- (void)documentInteractionController:(UIDocumentInteractionController*)controller willBeginSendingToApplication:(nullable NSString*)application
{
    NSLog(@"begin send : %@", application);
}
// 弹框消失的时候走的方法
-(void)documentInteractionControllerDidDismissOpenInMenu:(UIDocumentInteractionController*)controller
{
    NSLog(@"dissMiss");
}

#pragma mark - UIDocumentPickerDelegate
#ifdef __IPHONE_11_0
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray <NSURL *>*)urls
{
    NSURL *url = urls[0];
    NSString *fileName = [url lastPathComponent];
    //NSString *urlString = url.absoluteString;
    
    if ([iCloudManager iCloudEnable]) {
        [iCloudManager downloadWithDocumentURL:url callBack:^(id obj) {
            NSData *data = obj;
            
            //写入沙盒Documents
            NSString *path = [NSHomeDirectory() stringByAppendingString:[NSString stringWithFormat:@"/Documents/%@",fileName]];
            [data writeToFile:path atomically:YES];
            
            !self.pickfileBlock ? : self.pickfileBlock(path);
        }];
    }
}
#endif

// called if the user dismisses the document picker without selecting a document (using the Cancel button)
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller
{
    
}

// 选中icloud里的pdf文件
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {
//    BOOL fileUrlAuthozied = [url startAccessingSecurityScopedResource];
//    if(fileUrlAuthozied){
//        NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] init];
//        NSError *error;
//
//        [fileCoordinator coordinateReadingItemAtURL:url options:0 error:&error byAccessor:^(NSURL *newURL) {
//            UIViewController *rootVC = [UIApplication sharedApplication].delegate.window.rootViewController;
//            [rootVC dismissViewControllerAnimated:YES completion:NULL];
//            //[self sendFileMessageWithURL:newURL displayName:[[url path] lastPathComponent]];
//        }];
//        [url stopAccessingSecurityScopedResource];
//    }else{
//        //Error handling
//
//    }
    
    
    NSString *fileName = [url lastPathComponent];
    //NSString *urlString = url.absoluteString;
    
    if ([iCloudManager iCloudEnable]) {
        [iCloudManager downloadWithDocumentURL:url callBack:^(id obj) {
            NSData *data = obj;
            
            //写入沙盒Documents
            NSString *path = [NSHomeDirectory() stringByAppendingString:[NSString stringWithFormat:@"/Documents/%@",fileName]];
            [data writeToFile:path atomically:YES];
            
            !self.pickfileBlock ? : self.pickfileBlock(path);
        }];
    }
}

@end
