//
//  ZZDocument.h
//  iclouddrive
//
//  Created by Alan on 2019/7/23.
//  Copyright © 2019 Alan. All rights reserved.
//
/// iCloud 下载数据类
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZZDocument : UIDocument

@property (nonatomic, strong) NSData *data;

@end

NS_ASSUME_NONNULL_END
