//
//  iCloudManager.h
//  iclouddrive
//
//  Created by Alan on 2019/7/23.
//  Copyright © 2019 Alan. All rights reserved.
//
/// iCloud 下载数据管理类
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^downloadBlock)(id obj);

@interface iCloudManager : NSObject

+ (BOOL)iCloudEnable;

+ (void)downloadWithDocumentURL:(NSURL*)url callBack:(downloadBlock)block;

@end

NS_ASSUME_NONNULL_END
