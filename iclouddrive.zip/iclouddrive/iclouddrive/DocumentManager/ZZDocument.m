//
//  ZZDocument.m
//  iclouddrive
//
//  Created by Alan on 2019/7/23.
//  Copyright © 2019 Alan. All rights reserved.
//

#import "ZZDocument.h"

@implementation ZZDocument

- (BOOL)loadFromContents:(id)contents ofType:(NSString *)typeName error:(NSError * _Nullable __autoreleasing *)outError {
    self.data = contents;
    return YES;
}

@end
